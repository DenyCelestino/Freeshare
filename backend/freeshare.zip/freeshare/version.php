<?php 
include 'config.php';
include 'function.php';
$url=file_get_contents('php://input');
$data=json_decode($url,true);
jsonHeader();


$dados = array();
$sql = "SELECT * FROM fixing WHERE type='update'";

$query = mysqli_query($connect,$sql);

if(mysqli_num_rows($query)>0){

while($giftcard = mysqli_fetch_array($query)){

  $dados['fixing'][] = array(

    "id"=>intval($giftcard["id"]),
   "title"=>$giftcard["title"],
   "type"=>$giftcard["type"],
   "message"=>$giftcard["message"],
   "buttontext"=>$giftcard["buttontext"],
   "buttonlink"=>$giftcard["buttonlink"],
   "version"=>$giftcard["version"],
 




  );

  
}
echo json_encode($dados);
}
else{
echo json_encode('Sem tipos de giftcard');
exit();
}

mysqli_close($connect);





?>