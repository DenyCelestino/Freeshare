<?php 
include 'config.php';
include 'function.php';  
$url=file_get_contents('php://input');
$data=json_decode($url,true);
jsonHeader();


$page=noHacking(isset($_GET['page'])?$_GET['page']:1);


  $query = "SELECT * FROM gif";

 $res = mysqli_query($connect,$query);
 $total = mysqli_num_rows($res);



  
   $i=0;
   $j=[];
   
   
  while ($data= mysqli_fetch_assoc($res)):
      
     $j[$i]=[
     "id" => intval($data['id']),
     "gifimage" => $data['gifimage'],
     ];
  
  $i++;
  endwhile;
  echo json_encode (["items"=>$j,"total"=>$total]);
  mysqli_close($connect);





?>