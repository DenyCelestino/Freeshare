-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04-Nov-2022 às 08:06
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `freeshare`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `comments`
--

CREATE TABLE `comments` (
  `id` int(255) NOT NULL,
  `userid` int(255) NOT NULL,
  `postid` int(255) NOT NULL,
  `date` datetime NOT NULL,
  `content` text CHARACTER SET utf8mb4 NOT NULL,
  `giftrue` tinyint(1) NOT NULL,
  `gif` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `comments`
--

INSERT INTO `comments` (`id`, `userid`, `postid`, `date`, `content`, `giftrue`, `gif`) VALUES
(65, 6, 50, '2022-09-19 19:03:44', 'Asterix e Obelix kkkk... Adorava o desenhos', 1, 6),
(66, 19, 51, '2022-09-19 19:09:55', '', 1, 16),
(67, 18, 53, '2022-09-19 19:19:58', '', 1, 5),
(68, 18, 51, '2022-09-19 19:20:35', 'Adorava quando mais novo ainda', 1, 6),
(69, 18, 50, '2022-09-19 19:20:47', 'A lenda ', 0, 1),
(70, 18, 50, '2022-09-19 19:20:59', '', 1, 1),
(71, 18, 52, '2022-09-19 19:21:34', 'Eu posso ajudar rsrsrs', 1, 14),
(72, 18, 52, '2022-09-19 19:21:41', '😅😅😅😅😅😅😅🔥🔥', 0, 1),
(73, 3, 53, '2022-09-19 19:22:17', 'Woooooww', 0, 1),
(74, 3, 50, '2022-09-19 19:23:16', 'Eu indo ver agora ... Depois de muitos anos kkk', 1, 2),
(75, 21, 50, '2022-09-19 19:32:08', '❤️❤️❤️❤️🖤🖤🖤', 0, 1),
(76, 21, 50, '2022-09-19 19:32:24', '', 1, 3),
(77, 3, 56, '2022-09-20 11:46:02', '❤️❤️❤️', 0, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `gif`
--

CREATE TABLE `gif` (
  `id` int(255) NOT NULL,
  `gifimage` text CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `gif`
--

INSERT INTO `gif` (`id`, `gifimage`) VALUES
(1, 'gif/gifhearth.gif'),
(2, 'gif/gift2.gif'),
(3, 'gif/happy.gif'),
(4, 'gif/rickgif.gif'),
(5, 'gif/surprised1.gif'),
(6, 'gif/carinho1.gif'),
(7, 'gif/carinho2.gif'),
(8, 'gif/carinho3.gif'),
(9, 'gif/gay1.gif'),
(10, 'gif/gay2.gif'),
(12, 'gif/gay3.gif'),
(13, 'gif/riso1.gif'),
(14, 'gif/riso2.gif'),
(15, 'gif/riso3.gif'),
(16, 'gif/strike.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `posts`
--

CREATE TABLE `posts` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `user_google_id` text CHARACTER SET utf8mb4 NOT NULL,
  `time` datetime NOT NULL,
  `description` text CHARACTER SET utf8mb4 NOT NULL,
  `photo` text CHARACTER SET utf8mb4 NOT NULL,
  `links` text CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `user_google_id`, `time`, `description`, `photo`, `links`) VALUES
(50, 3, '107723718688014586675', '2022-09-19 19:02:33', 'Que lembra? 😅😅', 'images/773426328a0a974536.jpg', ''),
(51, 6, '115240181822093375210', '2022-09-19 19:04:18', 'Um dos melhores 😅❤️', 'images/121986328a1125e4b5.jpg', ''),
(52, 19, '115651492823707259979', '2022-09-19 19:08:00', 'Adele confessou:\nDefinitivamente, gostava de ter mais filhos&quot;, admitiu em conversa com Lauren Laverne, depois de a apresentadora ter perguntado à cantora como é que imagina a sua vida daqui a 10 anos. \n\n&quot;Seria maravilhoso se conseguíssemos. Se não, tanho o Angelo. Eu só quero ser feliz&quot;, acrescentou. \n\nDe recordar que Adele é mãe de Angelo, de nove anos, fruto do casamento terminado com Simon Konecki.\n\n', 'images/126086328a1f0b7b03.jpg', ''),
(53, 5, '107063303816886692982', '2022-09-19 19:13:44', 'A Rockstar confirmou, nesta segunda-feira (19), que de fato teve suas redes invadidas e que o material do próximo Grand Theft Auto vazado é legítimo. Em um comunicado, a desenvolvedora afirmou que não deverá interromper o desenvolvimento e que manterá o calendário já previsto.\n\n&quot;Recentemente, nós sofremos uma invasão de rede na qual um terceiro não autorizado acessou e baixou ilegalmente informações confidenciais de nossos sistemas, incluindo material em desenvolvimento para o próximo Grand Theft Auto&quot;, diz a empresa. O material em questão, supostamente, diz respeito ao jogo GTA 6, que ainda não foi anunciado.', 'images/328206328a348254dd.jpg', ''),
(54, 5, '107063303816886692982', '2022-09-19 19:15:14', 'O Nubank começou a receber, nesta segunda-feira (19), as inscrições para o seu Programa de Estágio 2023. Trata-se da primeira edição do projeto, que disponibiliza vagas para estudantes de todo o Brasil, interessados em atuar nas áreas de finanças, tecnologia e negócios.\n\nSegundo a fintech, as mais de 70 vagas de estágio oferecidas seguem um modelo remoto, possibilitando a participação de residentes em qualquer lugar do país. Apenas as oportunidades para os setores de Produto e Design exigem que os estagiários sejam da região de São Paulo (SP), pois incluem idas ao escritório a cada dois meses.\n\nFonte: TecMundo', '', ''),
(55, 5, '107063303816886692982', '2022-09-19 19:17:25', 'No último domingo (18), a Rockstar sofreu um dos maiores vazamentos da história do mundo dos games, com diversos clipes de GTA 6 sendo espalhados pela internet. Mesmo com pouco tempo após a liberação, os olhos mais atentos da rede conseguiram identificar alguns recursos que poderiam estar presentes no game, como um mensageiro similar ao WhatsApp.\n\nNo print abaixo, e em diversos outros momentos nos mais de 90 vídeos vazados, é possível perceber que algumas notificações pop-up aparecem na tela do usuário informando sobre mensagens ou novos contatos adicionados ao aplicativo &quot;WhatUp!&quot;. A plataforma do game e uma clara paródia do aplicativo de mensagens de Mark Zuckerberg, que é bastante popular no Brasil.\n\n', '', ''),
(56, 3, '107723718688014586675', '2022-09-20 11:45:30', '', 'images/4404263298bba035a6.jpg', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `name` text NOT NULL,
  `iduser` text NOT NULL,
  `email` text NOT NULL,
  `profile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `iduser`, `email`, `profile`) VALUES
(3, 'Delfim Celestino Amisse Pastola', '107723718688014586675', 'denycelestino21@gmail.com', 'https://lh3.googleusercontent.com/a-/AFdZucoIcF-A4zzfL7FUj3QyfHAFSS2GO2zHzcXfJpgg=s96-c'),
(4, 'Izilda Francisco', '106135940705171561028', 'izildafrancisco49@gmail.com', 'https://lh3.googleusercontent.com/a/AItbvmkajCn5nwBjdRcakQGfKeyJEfVvQI6FaWj9TB7N=s96-c'),
(5, 'bantu C', '107063303816886692982', 'bantuc9@gmail.com', 'https://lh3.googleusercontent.com/a-/AFdZucoMnaVPe96jfrpEEbqvITF3msyFeJ-FQ4Fdg_U=s96-c'),
(6, 'anonymous Fsociety', '115240181822093375210', 'juniorhala12@gmail.com', 'https://lh3.googleusercontent.com/a-/AFdZucoXIPmLEAAQqroeWCgDTaAxnzIaFN2iG2D7-ygi=s96-c'),
(18, 'moviefor people', '104982534013783609979', 'movieforpeople21@gmail.com', 'https://lh3.googleusercontent.com/a/AItbvmlHPLvKI2sjJwoU4-1wie8NULhs5TZyjHH1H6BM=s96-c'),
(19, 'Djamilleé Muachapeu', '115651492823707259979', 'djamilleemuachapeu21@gmail.com', 'https://lh3.googleusercontent.com/a-/AFdZucpvW-UB2uBxWkRId1Mh9UDacTbT12a_-R8WZTjv=s96-c'),
(21, 'Fsociety World', '102149972725397056314', 'apganonymous@gmail.com', 'https://lh3.googleusercontent.com/a-/ACNPEu_Sa5GBmKafGLXLwBZ8_EI-T4_NRQNKJyjTeZq8=s96-c');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `postid` (`postid`),
  ADD KEY `gif` (`gif`);

--
-- Índices para tabela `gif`
--
ALTER TABLE `gif`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT de tabela `gif`
--
ALTER TABLE `gif`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`postid`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`gif`) REFERENCES `gif` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
