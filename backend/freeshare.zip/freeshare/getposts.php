<?php 
include 'config.php';
include 'function.php';  
$url=file_get_contents('php://input');
$data=json_decode($url,true);
jsonHeader();


$page=noHacking(isset($_GET['page'])?$_GET['page']:1);

function comments($id){
   global $connect;
  $sql = "SELECT * FROM comments WHERE postid='$id'";
  $query = mysqli_query($connect,$sql);
  
  $total = mysqli_num_rows($query);
  
  return json_encode($total);
  
  
    }



  $query = "SELECT posts.id,posts.user_id as userid,posts.time, users.name,users.profile,users.iduser,posts.description,posts.photo,posts.links FROM posts JOIN users ON posts.user_id=users.id order by posts.id DESC";

 $res = mysqli_query($connect,$query);
 $total = mysqli_num_rows($res);

 $pagequantity = 5;
 $init = ($page*$pagequantity)-$pagequantity;



  $query = "SELECT posts.id,posts.user_id as userid,posts.time, users.name,users.profile,users.iduser,posts.description,posts.photo,posts.links FROM posts JOIN users ON posts.user_id=users.id  order by posts.id DESC  LIMIT $init, $pagequantity ";
  
  $result_bd2 = mysqli_query($connect, $query);
  
  
   $i=0;
   $j=[];
   
   if(mysqli_num_rows($result_bd2)>0){
  while ($data= mysqli_fetch_assoc($result_bd2)):
      
     $j[$i]=[
     "id" => intval($data['id']),
     "userid" => intval($data['userid']),
     "name"=>$data["name"],
     "time"=>$data["time"],
     "profile"=>$data["profile"],
     "profile"=>$data["profile"],
     "desc"=>$data["description"],
     "photo"=>$data["photo"],
     "links"=>$data["links"],
     "comments"=>comments($data['id']),
     "google_id"=>$data['iduser']
     ];
  
  $i++;
  endwhile;
  echo json_encode (["items"=>$j,"total"=>$total]);

}else{
 echo json_encode(["items"=>[],"total"=>$total]);
}
  mysqli_close($connect);






?>