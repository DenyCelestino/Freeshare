<?php 
include 'config.php';
include 'function.php';  
$url=file_get_contents('php://input');
$data=json_decode($url,true);
jsonHeader();


$id=noHacking(isset($data['id'])?$data['id']:'');
$page=noHacking(isset($_GET['page'])?$_GET['page']:1);


  $query = "SELECT comments.id,comments.content,comments.date,comments.giftrue,comments.postid, users.iduser as iduser,users.name,users.profile,gif.gifimage as gifimage FROM comments JOIN users ON comments.userid = users.id JOIN gif ON comments.gif = gif.id WHERE comments.postid='$id' order by comments.id ASC";

 $res = mysqli_query($connect,$query);
 $total = mysqli_num_rows($res);

 $pagequantity = 5;
 $init = ($page*$pagequantity)-$pagequantity;



  $query = "SELECT comments.id,comments.content,comments.date,comments.giftrue,comments.postid, users.iduser as iduser,users.name,users.profile,gif.gifimage as gifimage FROM comments JOIN users ON comments.userid = users.id JOIN gif ON comments.gif = gif.id WHERE comments.postid='$id' order by comments.id ASC  LIMIT $init, $pagequantity ";
  
  $result_bd2 = mysqli_query($connect, $query);
  
  
   $i=0;
   $j=[];
   

   
   if(mysqli_num_rows($result_bd2)>0){

    while ($data= mysqli_fetch_assoc($result_bd2)):
      
      $j[$i]=[
        "id" => intval($data['id']),
        "content"=>$data["content"],
        "date"=>$data["date"],
        "giftrue"=>boolval($data["giftrue"]),
        "iduser"=>$data["iduser"],
        "name"=>$data["name"],
        "profile"=>$data["profile"],
        "gifimage"=>$data["gifimage"],
        ];
    
    $i++;
    endwhile;
    echo json_encode (["items"=>$j,"total"=>$total]);

   }else{
    echo json_encode(["items"=>[],"total"=>$total]);
   }
   
 
  mysqli_close($connect);





?>