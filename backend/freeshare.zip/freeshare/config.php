<?php 
$database = 'freeshare';
$server='localhost';
$user='root';
$pass='';
$connect = mysqli_connect($server,$user,$pass,$database);
mysqli_set_charset($connect, "utf8mb4");



?>