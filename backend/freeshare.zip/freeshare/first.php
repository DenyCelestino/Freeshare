<?php 
include 'config.php';
include 'function.php';  
$url=file_get_contents('php://input');
$data=json_decode($url,true);
jsonHeader();

$iduser =noHacking( isset($data['iduser']) ? $data['iduser'] : '');
$email = noHacking(isset($data['email']) ? $data['email'] : '');
$profile = noHacking(isset($data['profile']) ? $data['profile'] : '');
$name = noHacking(isset($data['name']) ? $data['name'] : '');



$sql = "SELECT * FROM `users` WHERE iduser='$iduser' AND email='$email'";
$query = mysqli_query($connect,$sql);

if(mysqli_num_rows($query)>0){

echo json_encode(false);

}else{
  $sql = "INSERT INTO users (`iduser`,`email`,`profile`,`name`) VALUES ('$iduser','$email','$profile','$name')";
  $query = mysqli_query($connect,$sql);

  if(mysqli_affected_rows($connect)==1){

   echo json_encode(true);

  }else{

    echo json_encode('error');
  }
}






?>