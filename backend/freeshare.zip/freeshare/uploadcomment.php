<?php
 include 'config.php';
 include 'function.php';
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, PUT");
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
    


    $url = file_get_contents("php://input");
    $data=json_decode($url,true);
  

    $iduser=noHacking(isset($data['iduser'])?$data['iduser']:'');
    $content=noHacking(isset($data['content'])?$data['content']:'');
    $gifid=noHacking(isset($data['gifid'])?$data['gifid']:'');
    $postid=noHacking(isset($data['postid'])?$data['postid']:'');
  
     if(empty($gifid)){

      $gifstate = false;
      $gifid=1;
     }else{
      $gifstate = true;
     }
    

   $date= datenow();



  $sql = "SELECT * FROM users WHERE iduser='$iduser'";
    
  $query = mysqli_query($connect,$sql);
  if(mysqli_num_rows($query)>0){

    $data = mysqli_fetch_assoc($query);
    $id = $data['id'];

   
    $sql = "INSERT INTO comments (`userid`,`postid`,`date`,`content`,`giftrue`,`gif`) VALUES ('$id','$postid','$date','$content','$gifstate','$gifid')";

    $query = mysqli_query($connect,$sql);

    if(mysqli_affected_rows($connect)==1){

     

  $query = "SELECT comments.id,comments.content,comments.date,comments.giftrue,comments.postid, users.iduser as iduser,users.name,users.profile,gif.gifimage as gifimage FROM comments JOIN users ON comments.userid = users.id JOIN gif ON comments.gif = gif.id WHERE comments.postid='$postid' order by comments.id ASC ";
  
  $result_bd2 = mysqli_query($connect, $query);
  
  $total = mysqli_num_rows($result_bd2);
   $i=0;
   $j=[];
   

   
   if(mysqli_num_rows($result_bd2)>0){

    while ($data= mysqli_fetch_assoc($result_bd2)):
      
      $j[$i]=[
        "id" => intval($data['id']),
        "content"=>$data["content"],
        "date"=>$data["date"],
        "giftrue"=>boolval($data["giftrue"]),
        "iduser"=>$data["iduser"],
        "name"=>$data["name"],
        "profile"=>$data["profile"],
        "gifimage"=>$data["gifimage"],
        ];
    
    $i++;
    endwhile;
    echo json_encode (["items"=>$j,"total"=>$total]);

   }else{
    echo json_encode(["items"=>[],"total"=>$total]);
   }
    }else{
      echo json_encode('uploaded-error');
    }
   

   
  }else{
   echo json_encode('id-not-found');
  }


    
       
 mysqli_close($connect);

    
     

?>
