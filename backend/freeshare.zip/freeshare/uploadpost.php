<?php
 include 'config.php';
 include 'function.php';
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, PUT");
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
    


    $httpPost = file_get_contents("php://input");
    $req = json_decode(($httpPost));
    $data= json_decode($httpPost, TRUE);
    $base= base64_decode( $req->image);

    $iduser=noHacking(isset($data['iduser'])?$data['iduser']:'');
    $email=noHacking(isset($data['email'])?$data['email']:'');
    $desc=noHacking(isset($data['desc'])?$data['desc']:'');
    $links=noHacking(isset($data['links'])?$data['links']:'');
   

   $date= datenow();

   function comments($id){
    global $connect;
   $sql = "SELECT * FROM comments WHERE postid='$id'";
   $query = mysqli_query($connect,$sql);
   
   $total = mysqli_num_rows($query);
   
   return json_encode($total);
   
   
     }



 if(empty($base)){


  $sql = "SELECT * FROM users WHERE iduser='$iduser' AND email='$email'";
    
  $query = mysqli_query($connect,$sql);
  if(mysqli_num_rows($query)>0){

    $data = mysqli_fetch_assoc($query);
    $id = $data['id'];

    $sql = "INSERT INTO posts (`user_id`,`user_google_id`,`time`,`description`,`photo`,`links`) VALUES ('$id','$iduser','$date','$desc','','$links')";

    $query = mysqli_query($connect,$sql);

    if(mysqli_affected_rows($connect)==1){

     
   
  $query = "SELECT posts.id,posts.user_id as userid,posts.time, users.name,users.profile,users.iduser,posts.description,posts.photo,posts.links FROM posts JOIN users ON posts.user_id=users.id  order by posts.id DESC ";
  
  $result_bd2 = mysqli_query($connect, $query);
  $total = mysqli_num_rows($result_bd2);
  
   $i=0;
   $j=[];
   
   if(mysqli_num_rows($result_bd2)>0){
  while ($data= mysqli_fetch_assoc($result_bd2)):
      
     $j[$i]=[
     "id" => intval($data['id']),
     "userid" => intval($data['userid']),
     "name"=>$data["name"],
     "time"=>$data["time"],
     "profile"=>$data["profile"],
     "profile"=>$data["profile"],
     "desc"=>$data["description"],
     "photo"=>$data["photo"],
     "links"=>$data["links"],
     "comments"=>comments($data['id']),
     "google_id"=>$data['iduser']
     ];
  
  $i++;
  endwhile;
    echo json_encode (["items"=>$j,"total"=>$total]);

   }else{
    echo json_encode(["items"=>[],"total"=>$total]);
   }
    }else{
      echo json_encode('uploaded-error');
    }
   

   
  }else{
   echo json_encode('id-not-found');
  }

 }else{
  $path='images/'.  $data['name']. uniqid() .".". $data['format'];
  if(file_put_contents($path,$base)){
  
    $sql = "SELECT * FROM users WHERE iduser='$iduser' AND email='$email'";
    
    $query = mysqli_query($connect,$sql);
    if(mysqli_num_rows($query)>0){

      $data = mysqli_fetch_assoc($query);
      $id = $data['id'];

      $sql = "INSERT INTO posts (`user_id`,`user_google_id`,`time`,`description`,`photo`,`links`) VALUES ('$id','$iduser','$date','$desc','$path','$links')";

      $query = mysqli_query($connect,$sql);

      if(mysqli_affected_rows($connect)==1){

       
        
  $query = "SELECT posts.id,posts.user_id as userid,posts.time, users.name,users.profile,users.iduser,posts.description,posts.photo,posts.links FROM posts JOIN users ON posts.user_id=users.id  order by posts.id DESC ";
  
  $result_bd2 = mysqli_query($connect, $query);
  $total = mysqli_num_rows($result_bd2);
  
   $i=0;
   $j=[];
   
   if(mysqli_num_rows($result_bd2)>0){
  while ($data= mysqli_fetch_assoc($result_bd2)):
      
     $j[$i]=[
     "id" => intval($data['id']),
     "userid" => intval($data['userid']),
     "name"=>$data["name"],
     "time"=>$data["time"],
     "profile"=>$data["profile"],
     "profile"=>$data["profile"],
     "desc"=>$data["description"],
     "photo"=>$data["photo"],
     "links"=>$data["links"],
     "comments"=>comments($data['id']),
     "google_id"=>$data['iduser']
     ];
  
  $i++;
  endwhile;
    
  echo json_encode (["items"=>$j,"total"=>$total]);

}else{
 echo json_encode(["items"=>[],"total"=>$total]);
}
      }else{
        echo json_encode('uploaded-error');
      }
     

     
    }else{
     echo json_encode('id-not-found');
    }

  }else{
   echo json_encode('not moved');
  }

 }
    
       
 mysqli_close($connect);

    
     

?>
